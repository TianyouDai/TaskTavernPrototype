package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-10-16.
 */

public class MessageAdapter extends BaseAdapter {
    private final String UP_NAVIGATION_EXTRA = "UP_NAVIGATION";
    private final String SENDER_ID_EXTRA = "SENDER_ID";

    private Context mContext;
    private ArrayList<HashMap<String, String>> mDataSource;
    private LayoutInflater mInflater;

    public MessageAdapter(Context context, ArrayList<HashMap<String, String>> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        // Get view for row item
        View rowView = mInflater.inflate(R.layout.msg_list_item, viewGroup, false);

        // get elements
        Button userIconBtn        = (Button) rowView.findViewById(R.id.userIconBtn);
        TextView usernameTextView = (TextView) rowView.findViewById(R.id.usernameTextView);
        TextView content          = (TextView) rowView.findViewById(R.id.contentTextView);

        HashMap<String, String> msg = (HashMap<String, String>) getItem(position);

        String userOne = msg.get("sender");
        String userTwo = msg.get("recipient");
        final String _other = (LoginActivity.CURRENT_USER_ID.equals(userOne))? userTwo : userOne;

        DBTools db = new DBTools(mContext);
        String username = db.getUsernameFromID(_other);

        // populate views
        userIconBtn.setText(username.substring(0, 2));
        usernameTextView.setText(username);
        content.setText(shorten(msg.get("content"), 50));

        // assign click listeners
        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, MessageDetailActivity.class);
                intent.putExtra(UP_NAVIGATION_EXTRA, "MessageActivity");
                intent.putExtra(SENDER_ID_EXTRA, _other);
                mContext.startActivity(intent);
            }
        });

        return rowView;
    }

    private String shorten(String text, int numChar) {
        if (text.length() > numChar) {
            return String.format("%s...", text.substring(0, numChar-3));
        }
        return text;
    }

}
