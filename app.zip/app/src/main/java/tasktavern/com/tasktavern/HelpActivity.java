package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class HelpActivity extends AppCompatActivity {
    private final String UP_NAVIGATION_EXTRA = "UP_NAVIGATION";

    private String UP_NAV_LOCATION;

    private int slideNumber;
    private final int MAX_SLIDES = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        Bundle extras = getIntent().getExtras();
        UP_NAV_LOCATION = extras.getString(UP_NAVIGATION_EXTRA);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                if (UP_NAV_LOCATION.equals("TaskOverviewActivity")) {
                    Intent intent = new Intent(this, TaskOverviewActivity.class);
                    startActivity(intent);
                    finish();

                } else if (UP_NAV_LOCATION.equals("LoginActivity")) {
                    Intent intent = new Intent(this, LoginActivity.class);
                    startActivity(intent);
                    finish();

                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
