package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;

public class TaskOverviewActivity extends AppCompatActivity {
    private final String UP_NAVIGATION_EXTRA = "UP_NAVIGATION";

    private ListView mListView;
    private boolean myTasksFilter;
    private boolean completeTasksFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_overview);

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        boolean myTasksFilterPref = sharedPref.getBoolean("ownTasksByDefault", false);
        boolean completeTasksFilterPref = sharedPref.getBoolean("completedByDefault", false);

        myTasksFilter       = myTasksFilterPref;
        completeTasksFilter = completeTasksFilterPref;

        mListView = (ListView) findViewById(R.id.taskList);

    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> taskList = db.getTasks();

        // remove certain tasks depending on filter toggle state,
        // assigned user, and completed status
        if (myTasksFilter) {
            taskList = filterOutOtherTasks(taskList);
        }

        if (!completeTasksFilter) {
            taskList = filterOutCompleteTasks(taskList);
        }

        // Insert the filter row
        taskList.add(0, null);

        TaskOverviewAdapter adapter = new TaskOverviewAdapter(this, taskList);
        mListView.setAdapter(adapter);

    }

    public void requestOnResume() {
        onResume();
    }

    public void filterChange(String name, boolean state) {
        if (name.equals("MY_TASKS_TOGGLE")) {
            myTasksFilter = state;

        } else if (name.equals("COMPLETE_TASKS_TOGGLE")) {
            completeTasksFilter = state;

        }
        onResume(); // refresh task list
    }

    public boolean getMyTasksToggleState() {
        return myTasksFilter;
    }

    public boolean getCompleteTasksToggleState() {
        return completeTasksFilter;
    }

    private ArrayList<HashMap<String, String>> filterOutOtherTasks(ArrayList<HashMap<String, String>> taskList) {
        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();
        for (HashMap<String, String> item : taskList) {
            if (item.get("assigned").equals(LoginActivity.CURRENT_USER_ID)) {
                rtn.add(item);
            }
        }
        return rtn;
    }

    private ArrayList<HashMap<String, String>> filterOutCompleteTasks(ArrayList<HashMap<String, String>> taskList) {
        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();
        for (HashMap<String, String> item : taskList) {
            if (item.get("complete").equals("0")) {
                rtn.add(item);
            }
        }
        return rtn;
    }

    public void createTask(View view) {
        Intent intent = new Intent(this, CreateTaskActivity.class);
        startActivity(intent);
    }

    public void msgBtn(View view) {
        Intent intent = new Intent(this, MessageActivity.class);
        startActivity(intent);
    }

    public void groupBtn(View view) {
        Intent intent = new Intent(this, GroupActivity.class);
        startActivity(intent);
    }

    public void calendarBtn(View view) {
        Intent intent = new Intent(this, CalendarActivity.class);
        startActivity(intent);
    }

    public void helpBtn(View view) {
        Intent intent = new Intent(this, HelpActivity.class);
        intent.putExtra(UP_NAVIGATION_EXTRA, "TaskOverviewActivity");
        startActivity(intent);
    }

}
