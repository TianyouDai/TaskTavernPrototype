package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class ShoppingListActivity extends AppCompatActivity {

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);

        mListView = (ListView) findViewById(R.id.shopList);

    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> itemList = db.getShoppingItems();

        TextView uncompletedItems = (TextView) findViewById(R.id.uncompleteItemsTextView);
        int numItems = itemList.size();
        if (numItems == 0) {
            uncompletedItems.setText("shopping list empty");

        } else if (numItems == 1) {
            uncompletedItems.setText(Integer.toString(numItems) + " item remaining");

        } else {
            uncompletedItems.setText(Integer.toString(numItems) + " items remaining");

        }

        ShoppingListAdapter adapter = new ShoppingListAdapter(this, itemList);
        mListView.setAdapter(adapter);

    }

    public void clearCompleteItems(View view) {
        DBTools db = new DBTools(this);
        db.removeCompletedShoppingItems();
        onResume(); // refresh shop list
    }

    public void addItem(View view) {
        DBTools db = new DBTools(this);
        TextView itemNameTextView = (TextView) findViewById(R.id.newItemEditText);
        String name = itemNameTextView.getText().toString();

        if (!name.equals("")) {
            HashMap<String, String> item = new HashMap<>();
            item.put("name", name);
            item.put("complete", "0");
            db.createShoppingItem(item);
            itemNameTextView.setText("");
            onResume(); // refresh shopping list
        }
    }
}
