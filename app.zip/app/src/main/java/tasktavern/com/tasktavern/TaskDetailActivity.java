package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.BoolRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class TaskDetailActivity extends AppCompatActivity {
    private final String TASK_ID_EXTRA = "TAVERN_TASK_ID";

    private String TASK_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_detail);

        Bundle extras = getIntent().getExtras();
        TASK_ID = extras.getString(TASK_ID_EXTRA);

    }

    private String formatDate(String dateString) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = df.parse(dateString);
            return new SimpleDateFormat("dd MMM yy").format(date);

        } catch (Exception e) {
            return dateString;

        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);
        HashMap<String, String> task = db.getTaskWithID(TASK_ID);

        TextView taskTitle         = (TextView)findViewById(R.id.taskTitleTextView);
        Button userIcon            = (Button)findViewById(R.id.userIconBtn);
        TextView usernameTextView  = (TextView)findViewById(R.id.usernameTextView);
        TextView assignedTextView  = (TextView)findViewById(R.id.assignedTextView);
        TextView durationTextView  = (TextView)findViewById(R.id.duration);
        TextView deadlineTextView  = (TextView)findViewById(R.id.deadline);
        TextView createdByUsername = (TextView)findViewById(R.id.createdByTextView);
        TextView description       = (TextView)findViewById(R.id.descriptionTextView);
        Button releaseBtn          = (Button)findViewById(R.id.releaseBtn);

        taskTitle.setText(task.get("title"));

        final Context _context = this;
        final String _taskid = TASK_ID;
        final String userAssigned = task.get("assigned");

        if (userAssigned.equals("-1")) {
            userIcon.setText("+");
            usernameTextView.setText("unassigned");
            assignedTextView.setText("");
            releaseBtn.setVisibility(View.GONE);

            userIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(_context, AssignUserActivity.class);
                    intent.putExtra(TASK_ID_EXTRA, _taskid);
                    _context.startActivity(intent);
                }
            });

        } else {
            String username = db.getUsernameFromID(userAssigned);
            userIcon.setText(username.substring(0, 2));
            usernameTextView.setText(username);

            userIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(_context, UserDetailActivity.class);
                    intent.putExtra("DETAIL_USER_ID", userAssigned);
                    _context.startActivity(intent);
                }
            });

        }

        durationTextView.setText(String.format("%sh %smin", task.get("hours"), task.get("minutes")));
        deadlineTextView.setText(String.format("due: %s", formatDate(task.get("deadline"))));

        createdByUsername.setText(db.getUsernameFromID(task.get("createdby")));

        description.setText(task.get("description"));

        inflateResourcesViewArea();
        inflateGroupsViewArea();
    }

    public void editTask(View view) {
        Intent intent = new Intent(this, TaskEditActivity.class);
        intent.putExtra(TASK_ID_EXTRA, TASK_ID);
        startActivity(intent);
    }
    public void deleteTask(View view) {
        DBTools db = new DBTools(this);
        db.deleteTask(TASK_ID);
        finish();
    }

    public void releaseUser(View view) {
        DBTools db = new DBTools(this);
        db.setTaskAssignedUser(TASK_ID, "-1");
        onResume(); // reset the view
    }

    private void inflateResourcesViewArea() {
        ((ViewGroup)findViewById(R.id.leftResourceViewColumn)).removeAllViews();
        ((ViewGroup)findViewById(R.id.rightResourceViewColumn)).removeAllViews();

        // get resources
        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> resourceList = db.getResourcesForTask(TASK_ID);

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // for each resource inflate a view
        boolean toggle = true;
        for (HashMap<String, String> resource : resourceList) {

            // get inflatable view
            View rowView = mInflater.inflate(R.layout.resource_list_item, null);

            // inflate view
            TextView itemName = (TextView)rowView.findViewById(R.id.itemNameTextView);
            itemName.setText(resource.get("name"));

            // hide the delete btns in this particular instance of the view
            Button deleteBtn = (Button)rowView.findViewById(R.id.deleteBtn);
            deleteBtn.setVisibility(View.GONE);

            // get inflated views parent
            ViewGroup group;
            if (toggle) {
                group = (ViewGroup)findViewById(R.id.leftResourceViewColumn);

            } else {
                group = (ViewGroup)findViewById(R.id.rightResourceViewColumn);

            }
            toggle = !toggle;

            // insert view at correct location
            group.addView(rowView);

        }
    }

    private void inflateGroupsViewArea() {
        ((ViewGroup)findViewById(R.id.leftGroupViewColumn)).removeAllViews();
        ((ViewGroup)findViewById(R.id.rightGroupViewColumn)).removeAllViews();

        // get resources
        DBTools db = new DBTools(this);
        ArrayList<String> groupList = db.getGroupsForTask(TASK_ID);

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // for each resource inflate a view
        boolean toggle = true;
        for (String group: groupList) {

            // get inflatable view
            View rowView = mInflater.inflate(R.layout.resource_list_item, null);

            // inflate view
            TextView itemName = (TextView)rowView.findViewById(R.id.itemNameTextView);
            itemName.setText(group);

            // hide the delete btns in this particular instance of the view
            Button deleteBtn = (Button)rowView.findViewById(R.id.deleteBtn);
            deleteBtn.setVisibility(View.GONE);

            // get inflated views parent
            ViewGroup viewGroup;
            if (toggle) {
                viewGroup = (ViewGroup)findViewById(R.id.leftGroupViewColumn);

            } else {
                viewGroup = (ViewGroup)findViewById(R.id.rightGroupViewColumn);

            }
            toggle = !toggle;

            // insert view at correct location
            viewGroup.addView(rowView);

        }
    }
}
