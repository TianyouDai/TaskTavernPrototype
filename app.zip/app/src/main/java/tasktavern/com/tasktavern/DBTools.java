package tasktavern.com.tasktavern;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

/**
 * Created by richardhayes on 2017-10-09.
 */

public class DBTools extends SQLiteOpenHelper {

    public DBTools(Context appContext){
        super(appContext, "tasktavern.db", null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE users ( " +
                "userid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "username TEXT," +
                "passcode INTEGER)";
        db.execSQL(query);

        String query2 = "CREATE TABLE tasks ( " +
                "taskid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "title TEXT," +
                "assigned INTEGER," +
                "hours INTEGER," +
                "minutes INTEGER," +
                "deadline DATE," +
                "description TEXT," +
                "created DATETIME," +
                "createdby INTEGER," +
                "complete INTEGER" +
                ")";
        db.execSQL(query2);

        String query3 = "CREATE TABLE messages ( " +
                "messageid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "sender INTEGER," +
                "recipient INTEGER," +
                "content TEXT," +
                "sent DATE," +
                "viewed INTEGER)";
        db.execSQL(query3);

        String query4 = "CREATE TABLE shopping ( " +
                "itemid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "name TEXT," +
                "complete INTEGER)";
        db.execSQL(query4);

        String query5 = "CREATE TABLE resources ( " +
                "resid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "taskid INTEGER," +
                "name TEXT)";
        db.execSQL(query5);

        String query6 = "CREATE TABLE groups ( " +
                "groupid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "name TEXT)";
        db.execSQL(query6);

        // table for the many to many association between tasks and groups
        String query7 = "CREATE TABLE taskGroup ( " +
                "rowid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "taskid INTEGER," +
                "groupid INTEGER)";
        db.execSQL(query7);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS users";
        db.execSQL(query);

        String query2 = "DROP TABLE IF EXISTS tasks";
        db.execSQL(query2);

        String query3 = "DROP TABLE IF EXISTS messages";
        db.execSQL(query3);

        String query4 = "DROP TABLE IF EXISTS shopping";
        db.execSQL(query4);

        String query5 = "DROP TABLE IF EXISTS resources";
        db.execSQL(query5);

        String query6 = "DROP TABLE IF EXISTS groups";
        db.execSQL(query6);

        String query7 = "DROP TABLE IF EXISTS taskGroup";
        db.execSQL(query7);

        onCreate(db);

    }

    public void resetDB() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "DROP TABLE IF EXISTS users";
        db.execSQL(query);

        String query2 = "DROP TABLE IF EXISTS tasks";
        db.execSQL(query2);

        String query3 = "DROP TABLE IF EXISTS messages";
        db.execSQL(query3);

        String query4 = "DROP TABLE IF EXISTS shopping";
        db.execSQL(query4);

        String query5 = "DROP TABLE IF EXISTS resources";
        db.execSQL(query5);

        String query6 = "DROP TABLE IF EXISTS groups";
        db.execSQL(query6);

        String query7 = "DROP TABLE IF EXISTS taskGroup";
        db.execSQL(query7);

        onCreate(db);

    }

    public void createUser(String username, int passcode) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("username", username);
        values.put("passcode", passcode);

        db.insert("users", null, values);

    }

    public long createTask(HashMap<String, String> task) {
        // returns id of task after creation
        SQLiteDatabase db = this.getWritableDatabase();

        /*
        taskid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
        title TEXT
        assigned INTEGER
        hours INTEGER
        minutes INTEGER
        deadline DATE
        manditory INTEGER
        description TEXT
        created DATETIME
        createdBy INTEGER (FK) */

        ContentValues values = new ContentValues();

        values.put("title",       task.get("title"));
        values.put("assigned",    task.get("assigned"));
        values.put("hours",       task.get("hours"));
        values.put("minutes",     task.get("minutes"));
        values.put("deadline",    task.get("deadline"));
        values.put("description", task.get("description"));
        values.put("created",     task.get("created"));
        values.put("createdby",   task.get("createdby"));
        values.put("complete",    task.get("complete"));

        long pk = db.insert("tasks", null, values);
        return pk;

    }

    public void createMessage(HashMap<String, String> msg) {
        SQLiteDatabase db = this.getWritableDatabase();

        /*
        messageid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
        sender INTEGER
        recipient INTEGER
        content TEXT
        sent DATE
        viewed INTEGER */

        ContentValues values = new ContentValues();

        values.put("messageid", msg.get("messageid"));
        values.put("sender",    msg.get("sender"));
        values.put("recipient", msg.get("recipient"));
        values.put("content",   msg.get("content"));
        values.put("sent",      msg.get("sent"));
        values.put("viewed",    msg.get("viewed"));

        db.insert("messages", null, values);

    }

    public long createResource(HashMap<String, String> resource) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("taskid", resource.get("taskid"));
        values.put("name",   resource.get("name"));

        return db.insert("resources", null, values);

    }

    public long createGroup(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteDatabase dbr = this.getReadableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);

        // prevent creation of duplicate groups
        if (DatabaseUtils.queryNumEntries(dbr, "groups", "name=?", new String[]{name} ) == 0) {
            return db.insert("groups", null, values);
        }
        return -1;
    }

    public void createShoppingItem(HashMap<String, String> item) {
        SQLiteDatabase db = this.getWritableDatabase();

        /*
        itemid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
        name INTEGER
        complete INTEGER */

        ContentValues values = new ContentValues();

        values.put("name",    item.get("name"));
        values.put("complete", item.get("complete"));

        db.insert("shopping", null, values);

    }

    public void createShoppingItem(String name, String complete) {
        SQLiteDatabase db = this.getWritableDatabase();

        /*
        itemid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
        name INTEGER
        complete INTEGER */

        ContentValues values = new ContentValues();

        values.put("name",    name);
        values.put("complete", complete);

        db.insert("shopping", null, values);

    }

    public void updateTask(HashMap<String, String> task) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("title",       task.get("title"));
        values.put("assigned",    task.get("assigned"));
        values.put("hours",       task.get("hours"));
        values.put("minutes",     task.get("minutes"));
        values.put("deadline",    task.get("deadline"));
        values.put("description", task.get("description"));
        values.put("created",     task.get("created"));
        values.put("createdby",   task.get("createdby"));

        db.update("tasks", values, "taskid=" + task.get("taskid"), null);

    }

    public void setTaskCompletion(String taskid, String status) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("complete", status);

        db.update("tasks", values, "taskid=" + taskid, null);
    }

    public void setItemCompletion(String itemid, String status) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("complete", status);

        db.update("shopping", values, "itemid=" + itemid, null);
    }

    public void setTaskAssignedUser(String taskid, String userid) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("assigned", userid);

        db.update("tasks", values, "taskid=" + taskid, null);
    }

    public void deleteTask(String taskid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(String.format("DELETE FROM tasks WHERE taskid=%s", taskid));
    }

    public void deleteGroup(String groupid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(String.format("DELETE FROM groups WHERE groupid=%s", groupid));
        db.execSQL(String.format("DELETE FROM taskGroup WHERE groupid=%s", groupid));
    }

    public void deleteResourcesForTask(String taskid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(String.format("DELETE FROM resources WHERE taskid=%s", taskid));
    }

    public void deleteUser(String userid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(String.format("DELETE FROM users WHERE userid=%s", userid));

        // remove user from any tasks they are assigned too
        ContentValues values = new ContentValues();
        values.put("assigned", "-1");
        db.update("tasks", values, "assigned=" + userid, null);

    }

    public void deleteGroupsForTask(String taskid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(String.format("DELETE FROM taskGroup WHERE taskid=%s", taskid));
    }

    public ArrayList<HashMap<String, String>> getUsers() {

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from users";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {
                HashMap<String, String> temp = new HashMap<>();
                temp.put("userid", cursor.getString(0));
                temp.put("username", cursor.getString(1));
                temp.put("passcode", cursor.getString(2));
                temp.put("pendingtasks", "0");
                temp.put("nexttask", "task title");

                rtn.add(temp);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public ArrayList<HashMap<String, String>> getTasks() {

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from tasks ORDER BY deadline ASC";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {
                HashMap<String, String> temp = new HashMap<>();
                temp.put("taskid",      cursor.getString(0));
                temp.put("title",       cursor.getString(1));
                temp.put("assigned",    cursor.getString(2));
                temp.put("hours",       cursor.getString(3));
                temp.put("minutes",     cursor.getString(4));
                temp.put("deadline",    cursor.getString(5));
                temp.put("description", cursor.getString(6));
                temp.put("created",     cursor.getString(7));
                temp.put("createdby",   cursor.getString(8));
                temp.put("complete",   cursor.getString(9));

                rtn.add(temp);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public long getCompletedTasksForUser(String userid) {
        SQLiteDatabase db = this.getReadableDatabase();

        return DatabaseUtils.queryNumEntries(db, "tasks", "assigned=? AND complete=?", new String[]{userid, "1"} );
    }

    public ArrayList<HashMap<String, String>> getGroups() {

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from groups";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {
                HashMap<String, String> temp = new HashMap<>();
                temp.put("groupid",      cursor.getString(0));
                temp.put("name",       cursor.getString(1));

                rtn.add(temp);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public HashMap<String, Boolean> getGroupIdsForTask(String taskid) {
        // returns map that can be used to check if what groups a task is a part of
        SQLiteDatabase db = this.getReadableDatabase();

        HashMap<String, Boolean> rtn = new HashMap<>();

        String selectQuery = "SELECT * from taskGroup WHERE taskid=" + taskid;

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {

                rtn.put(cursor.getString(2), true);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public ArrayList<String> getGroupsForTask(String taskid) {
        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<String> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from taskGroup INNER JOIN groups USING (groupid) WHERE taskid=" + taskid;

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {

                rtn.add(cursor.getString(3));

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public ArrayList<HashMap<String, String>> getTasksForGroup(String groupid) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * from taskGroup INNER JOIN tasks USING (taskid) WHERE groupid=" + groupid;

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {

                HashMap<String, String> temp = new HashMap<>();
                temp.put("rowid",   cursor.getString(0));
                temp.put("taskid",  cursor.getString(1));
                temp.put("groupid", cursor.getString(2));
                temp.put("tasktitle", cursor.getString(3));

                rtn.add(temp);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public void addTaskToGroup(String taskid, String groupid) {
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteDatabase dbr = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("taskid", taskid);
        values.put("groupid", groupid);

        // prevent task being added to same group twice
        if (DatabaseUtils.queryNumEntries(dbr, "taskGroup", "taskid=? AND groupid=?", new String[]{taskid, groupid} ) == 0) {
            db.insert("taskGroup", null, values);
        }

    }

    public void removeTaskFromGroup(String taskid, String groupid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(String.format("DELETE FROM taskGroup WHERE taskid=" + taskid + " AND groupid=" + groupid));

    }

    public ArrayList<HashMap<String, String>> getResourcesForTask(String taskid) {

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from resources WHERE taskid=" + taskid;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {
                HashMap<String, String> temp = new HashMap<>();
                temp.put("resid",  cursor.getString(0));
                temp.put("taskid", cursor.getString(1));

                Log.d("DBTools", cursor.getString(2));

                temp.put("name",   cursor.getString(2));

                rtn.add(temp);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public ArrayList<String> getResourcesForGroup(String groupid) {

        ArrayList<String> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from taskGroup WHERE groupid=" + groupid;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {

                String query = "SELECT * from resources WHERE taskid=" + cursor.getString(1);
                Cursor c2 = db.rawQuery(query, null);

                if (c2.moveToFirst()){

                    do {

                        rtn.add(c2.getString(2));

                    } while (c2.moveToNext());

                }

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public long getPendingTasksForUser(String assigned) {
        SQLiteDatabase db = this.getReadableDatabase();
        return DatabaseUtils.queryNumEntries(db, "tasks", "assigned=" + assigned + " AND complete=0");

    }

    public String getNextTaskForUser(String assigned) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query ("tasks", new String[]{"title"}, "assigned=" + assigned + " AND complete=0", null, null, null, "deadline ASC", "1");

        String nextTaskName = "no assigned tasks";
        if (cursor.moveToFirst()) {
            nextTaskName = cursor.getString(0);

        }
        cursor.close();
        return nextTaskName;
    }

    public ArrayList<HashMap<String, String>> getMessageFeed(String recipient, String sender){

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        String selectQuery = String.format(
                "SELECT * from messages WHERE (sender=%s AND recipient=%s) OR (sender=%s AND recipient=%s) ORDER BY sent ASC",
                sender, recipient, recipient, sender);

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {
                HashMap<String, String> temp = new HashMap<>();
                temp.put("messageid", cursor.getString(0));
                temp.put("sender",    cursor.getString(1));
                temp.put("recipient", cursor.getString(2));
                temp.put("content",   cursor.getString(3));
                temp.put("sent",      cursor.getString(4));
                temp.put("viewed",    cursor.getString(5));

                rtn.add(temp);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public ArrayList<HashMap<String, String>> getMostRecentMsgPerUser(String recipient) {

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from users";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        ArrayList<String> userids = new ArrayList<>();

        if (cursor.moveToFirst()){

            do {
                userids.add(cursor.getString(0));

            } while (cursor.moveToNext());
        }

        for (String userid : userids) {

            selectQuery = String.format(
                    "SELECT * FROM messages WHERE (recipient=%s AND sender=%s) OR (recipient=%s AND sender=%s) ORDER BY sent DESC LIMIT 1",
                    recipient, userid, userid, recipient);

            cursor = db.rawQuery(selectQuery, null);

            if (cursor.moveToFirst()){

                do {

                    HashMap<String, String> temp = new HashMap<>();
                    temp.put("messageid", cursor.getString(0));
                    temp.put("sender",    cursor.getString(1));
                    temp.put("recipient", cursor.getString(2));
                    temp.put("content",   cursor.getString(3));
                    temp.put("sent",      cursor.getString(4));
                    temp.put("viewed",    cursor.getString(5));

                    rtn.add(temp);

                } while (cursor.moveToNext());

            }
        }

        cursor.close();
        return rtn;
    }


    public HashMap<String, String> getTaskWithID(String taskid) {

        String selectQuery = String.format("SELECT * from tasks WHERE taskid=%s", taskid);

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            HashMap<String, String> temp = new HashMap<>();
            temp.put("taskid",      cursor.getString(0));
            temp.put("title",       cursor.getString(1));
            temp.put("assigned",    cursor.getString(2));
            temp.put("hours",       cursor.getString(3));
            temp.put("minutes",     cursor.getString(4));
            temp.put("deadline",    cursor.getString(5));
            temp.put("description", cursor.getString(6));
            temp.put("created",     cursor.getString(7));
            temp.put("createdby",   cursor.getString(8));

            return temp;
        }
        return null;
    }

    public String getUsernameFromID(String userid) {

        String selectQuery = String.format("SELECT * from users WHERE userid=%s", userid);

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){
            return cursor.getString(1);
        }
        return null;
    }

    public ArrayList<HashMap<String, String>> getShoppingItems() {

        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();

        String selectQuery = "SELECT * from shopping";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){

            do {
                HashMap<String, String> temp = new HashMap<>();
                temp.put("itemid",      cursor.getString(0));
                temp.put("name",       cursor.getString(1));
                temp.put("complete",    cursor.getString(2));

                rtn.add(temp);

            } while (cursor.moveToNext());

        }

        cursor.close();
        return rtn;
    }

    public void removeCompletedShoppingItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(String.format("DELETE FROM shopping WHERE complete=1"));

    }
}
