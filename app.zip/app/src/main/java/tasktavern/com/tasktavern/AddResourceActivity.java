package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class AddResourceActivity extends AppCompatActivity {

    private ListView mListView;
    ArrayList<String> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_resource);

        mListView = (ListView) findViewById(R.id.resourceList);

        Bundle extras = getIntent().getExtras();
        itemList = extras.getStringArrayList("RESOURCE_ITEMS");
    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);

        TextView uncompletedItems = (TextView) findViewById(R.id.uncompleteItemsTextView);
        int numItems = itemList.size();
        if (numItems == 0) {
            uncompletedItems.setText("resource list empty");

        } else if (numItems == 1) {
            uncompletedItems.setText(Integer.toString(numItems) + " resource");

        } else {
            uncompletedItems.setText(Integer.toString(numItems) + " resources");

        }

        AddResourceAdapter adapter = new AddResourceAdapter(this, itemList);
        mListView.setAdapter(adapter);

    }

    public void requestOnResume(){
        onResume();
    }

    public void addItem(View view) {
        TextView itemNameTextView = (TextView) findViewById(R.id.newItemEditText);
        String name = itemNameTextView.getText().toString();

        if (!name.equals("")) {
            itemList.add(name);
            itemNameTextView.setText("");
            onResume(); // refresh resource list
        }
    }

    public void saveResourcesBtn(View view) {
        Intent returnIntent = new Intent();
        returnIntent.putExtra("RESOURCE_ITEMS", itemList);
        setResult(RESULT_OK, returnIntent);
        finish();
    }

    public void cancelBtn(View view) {
        Intent returnIntent = new Intent();
        setResult(RESULT_CANCELED, returnIntent);
        finish();
    }
}
