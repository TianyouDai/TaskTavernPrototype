package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class SendMessageActivity extends AppCompatActivity {

    ArrayList<RadioButton> radioButtons;
    private String SELECTED_USER_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);

        // build list of users that can be assigned as recipient
        radioButtons = new ArrayList<>();
        inflateAssignedUserSelectionArea();

    }

    void inflateAssignedUserSelectionArea() {

        // get users
        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> userList = db.getUsers();

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // for each user inflate a view
        boolean toggle    = true;
        boolean firstUser = true;
        for (HashMap<String, String> user : userList) {
            // get userid
            final String _userid = user.get("userid");

            // skip the currently logged in user
            if (_userid.equals(LoginActivity.CURRENT_USER_ID)) {
                continue;
            }

            // get inflatable view
            View rowView = mInflater.inflate(R.layout.user_assigned_item, null);

            // inflate view
            RadioButton userItem = (RadioButton) rowView.findViewById(R.id.userSelectRadioBtn);
            userItem.setText(user.get("username"));
            userItem.setId(Integer.parseInt(_userid));

            // default check the first user in the list
            if (firstUser) {
                SELECTED_USER_ID = _userid;
                userItem.setChecked(true);
                firstUser = false;
            }

            // track created radio button
            radioButtons.add(userItem);

            // set up click listener
            userItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SELECTED_USER_ID = _userid;
                    clearRadioButtons();
                    ((RadioButton)view).setChecked(true);
                }
            });

            // get inflated views parent
            ViewGroup group;
            if (toggle) {
                group = (ViewGroup)findViewById(R.id.leftUserSelectColumn);

            } else {
                group = (ViewGroup)findViewById(R.id.rightUserSelectColumn);

            }
            toggle = !toggle;

            // insert view at correct location
            group.addView(rowView);

        }

    }

    void clearRadioButtons() {
        for (RadioButton btn : radioButtons) {
            btn.setChecked(false);
        }
    }

    public void sendMessage(View view) {
        TextView contentTextView = (TextView) findViewById(R.id.messageContent);

        Log.d("SndMsgAct", "here");
        Log.d("SndMsgAct", contentTextView.getText().toString());

        if (!contentTextView.getText().toString().equals("")) {
            HashMap<String, String> msg = new HashMap<>();
            msg.put("sender", LoginActivity.CURRENT_USER_ID);
            msg.put("recipient", SELECTED_USER_ID);
            msg.put("content", contentTextView.getText().toString());
            msg.put("sent", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            msg.put("viewed", "0");

            DBTools db = new DBTools(this);
            db.createMessage(msg);

            Intent intent = new Intent(this, MessageActivity.class);
            startActivity(intent);
            finish();

        }
    }
}
