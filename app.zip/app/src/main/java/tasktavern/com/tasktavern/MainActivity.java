package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // DEMO - RESET DB on start
        if (false) { (new DBTools(this)).resetDB(); }

        // DEMO - create demo data
        if (true) {
            SampleDataCreator debugData = new SampleDataCreator(this);
            debugData.createData();

        }

    }

    public void titleClick(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

}
