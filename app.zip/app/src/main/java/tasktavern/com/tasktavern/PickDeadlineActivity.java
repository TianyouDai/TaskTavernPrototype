package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;

public class PickDeadlineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_deadline);
    }

    String padValue(int value) {
        return (value <= 9)? "0" + value : Integer.toString(value);
    }

    public void saveDeadline(View view) {

        DatePicker picker = (DatePicker)findViewById(R.id.deadlineDatePicker);
        String date = picker.getYear() + "-" + padValue(picker.getMonth() + 1) + "-" + padValue(picker.getDayOfMonth());

        Intent returnIntent = new Intent();
        returnIntent.putExtra("DEADLINE_SELECTED", date);
        setResult(RESULT_OK, returnIntent);
        finish();
    }
}
