package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class UserDetailActivity extends AppCompatActivity {
    private final String UP_NAVIGATION_EXTRA  = "UP_NAVIGATION";
    private final String SENDER_ID_EXTRA      = "SENDER_ID";
    private final String DETAIL_USER_ID_EXTRA = "DETAIL_USER_ID";//passing extras

    private String DETAIL_USER_ID;
    private ListView mListView;
    private String UP_NAV_LOCATION;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);

        Bundle extras = getIntent().getExtras();
        UP_NAV_LOCATION = extras.getString(UP_NAVIGATION_EXTRA);
        DETAIL_USER_ID  = extras.getString(DETAIL_USER_ID_EXTRA);

        Button userIconBtn         = (Button) findViewById(R.id.userIconBtn);
        TextView usernameTextView  = (TextView) findViewById(R.id.usernameTextView);
        TextView pointsTextView    = (TextView) findViewById(R.id.pointsTextView);
        ImageView messageImageView = (ImageView) findViewById(R.id.messageUserImageView);
        Button deleteBtn           = (Button) findViewById(R.id.deleteBtn);

        // user cannot message themselves
        if (LoginActivity.CURRENT_USER_ID.equals(DETAIL_USER_ID)) {
            messageImageView.setVisibility(View.GONE);
            deleteBtn.setVisibility(View.VISIBLE);

        }

        DBTools db = new DBTools(this);//instance of database, given the id and returns the username
        String username = db.getUsernameFromID(DETAIL_USER_ID);
        userIconBtn.setText(username.substring(0, 2));//onces received the first two letters
        usernameTextView.setText(username);//uses two letters

        // user receives 10 points for each completed task
        pointsTextView.setText("Points: " + db.getCompletedTasksForUser(DETAIL_USER_ID) * 10);

        mListView = (ListView) findViewById(R.id.assignedTasksListView);//getting list of tasks

    }

    @Override
    protected void onResume() {//leave the screen, the screen remains there. If you delete anything, the task will be dispeared in the list
        super.onResume();

        //ask database, what task you have have so far
        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> taskList = db.getTasks();

        // show only tasks assigned to this user
        taskList = filterOutOtherTasks(taskList);

        UserDetailAdapter adapter = new UserDetailAdapter(this, taskList);
        mListView.setAdapter(adapter);//pass an adapter

    }

    private ArrayList<HashMap<String, String>> filterOutOtherTasks(ArrayList<HashMap<String, String>> taskList) {
        ArrayList<HashMap<String, String>> rtn = new ArrayList<>();
        for (HashMap<String, String> item : taskList) {
            if (item.get("assigned").equals(DETAIL_USER_ID)) {
                rtn.add(item);
            }
        }
        return rtn;//display the assigned tasks to that specific user
    }

    public void messageUser(View view) {
        Intent intent = new Intent(this, MessageDetailActivity.class);
        intent.putExtra(UP_NAVIGATION_EXTRA, "UserDetailActivity");
        intent.putExtra(SENDER_ID_EXTRA, DETAIL_USER_ID);
        startActivity(intent);

    }

    public void deleteUserBtn(View view) {
        DBTools db = new DBTools(this);
        db.deleteUser(LoginActivity.CURRENT_USER_ID);
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
