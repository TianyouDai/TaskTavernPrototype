package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class GroupResourcesActivity extends AppCompatActivity {

    private String GROUPID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_resources);

        Bundle extras = getIntent().getExtras();
        GROUPID = extras.getString("GROUPID");

        ViewGroup viewGroup = (ViewGroup) findViewById(R.id.resListTableLayout);
        viewGroup.removeAllViews();

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        DBTools db = new DBTools(this);
        ArrayList<String> resources = db.getResourcesForGroup(GROUPID);

        for (String name : resources) {
            // get inflatable view
            View rowView = mInflater.inflate(R.layout.resource_list_item, null);

            TextView resNameTextView = (TextView) rowView.findViewById(R.id.itemNameTextView);
            ((Button) rowView.findViewById(R.id.deleteBtn)).setVisibility(View.GONE);

            resNameTextView.setText(name);

            // insert view at correct location
            viewGroup.addView(rowView);
        }
    }
}
