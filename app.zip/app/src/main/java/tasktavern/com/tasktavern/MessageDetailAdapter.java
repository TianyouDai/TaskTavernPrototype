package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-10-17.
 */

public class MessageDetailAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<HashMap<String, String>> mDataSource;
    private LayoutInflater mInflater;

    public MessageDetailAdapter(Context context, ArrayList<HashMap<String, String>> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        // Get view for row item
        View rowView = mInflater.inflate(R.layout.msg_detail_list_item, viewGroup, false);

        // get elements
        TextView content  = (TextView) rowView.findViewById(R.id.messageContent);
        TextView dateSent = (TextView) rowView.findViewById(R.id.dateSent);
        LinearLayout messageContainer = (LinearLayout) rowView.findViewById(R.id.messageContainer);

        HashMap<String, String> msg = (HashMap<String, String>) getItem(position);

        // populate views
        content.setText(msg.get("content"));
        dateSent.setText(msg.get("sent"));

        // highlight messages sent by current user
        String sender = msg.get("sender");
        if (sender.equals(LoginActivity.CURRENT_USER_ID)) {
            messageContainer.setBackgroundResource(R.drawable.menubuttonshape);
        }

        return rowView;
    }

}
