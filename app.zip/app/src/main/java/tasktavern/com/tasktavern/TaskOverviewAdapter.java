package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-10-09.
 */

public class TaskOverviewAdapter extends BaseAdapter {
    private final String UP_NAVIGATION_EXTRA = "UP_NAVIGATION";
    private final String TASK_ID_EXTRA       = "TAVERN_TASK_ID";

    private Context mContext;
    private ArrayList<HashMap<String, String>> mDataSource;
    private LayoutInflater mInflater;

    public TaskOverviewAdapter(Context context, ArrayList<HashMap<String, String>> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private String formatDate(String dateString) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = df.parse(dateString);
            return new SimpleDateFormat("dd MMM yy").format(date);

        } catch (Exception e) {
            return dateString;

        }
    }

    private View getFilterView(View view, ViewGroup viewGroup) {
        // Get view for row item
        View rowView = mInflater.inflate(R.layout.filter_list_item, viewGroup, false);
        final ToggleButton myTasksToggle       = (ToggleButton) rowView.findViewById(R.id.myTasksToggle);
        final ToggleButton completeTasksToggle = (ToggleButton) rowView.findViewById(R.id.completeTasksToggle);

        final TaskOverviewActivity parent = (TaskOverviewActivity)mContext;

        myTasksToggle.setChecked(parent.getMyTasksToggleState());
        completeTasksToggle.setChecked(parent.getCompleteTasksToggleState());

        myTasksToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                parent.filterChange("MY_TASKS_TOGGLE", b);
            }
        });

        completeTasksToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                parent.filterChange("COMPLETE_TASKS_TOGGLE", b);
            }
        });

        return rowView;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        if (position == 0) {
            return getFilterView(view, viewGroup);
        }

        // Get view for row item
        View rowView = mInflater.inflate(R.layout.task_list_item, viewGroup, false);

        // get elements
        Button userIcon   = (Button) rowView.findViewById(R.id.userIconBtn);
        TextView taskname = (TextView) rowView.findViewById(R.id.tasknameTextView);
        TextView deadline = (TextView) rowView.findViewById(R.id.deadlineTextView);
        TextView note     = (TextView) rowView.findViewById(R.id.noteTextView);
        CheckBox done     = (CheckBox) rowView.findViewById(R.id.doneCheckbox);

        HashMap<String, String> task = (HashMap<String, String>) getItem(position);

        done.setChecked( task.get("complete").equals("1")?true:false );

        DBTools db = new DBTools(mContext);

        String assigned = task.get("assigned");

        if (!assigned.equals("-1")) {
            String username = db.getUsernameFromID(assigned);
            userIcon.setText(String.format("%s", username.substring(0,2)));

        } else {
            userIcon.setText("+");

        }

        taskname.setText(task.get("title"));

        deadline.setText(String.format("deadline: %s", formatDate(task.get("deadline"))));
        note.setText(String.format("note: %s", shorten(task.get("description"), 11)));

        final String _taskid   = task.get("taskid");
        final String _assigned = task.get("assigned");

        userIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // if user unassigned go to AssignUserActivity
                if (_assigned.equals("-1")) {
                    Intent intent = new Intent(mContext, AssignUserActivity.class);
                    intent.putExtra(TASK_ID_EXTRA, _taskid);
                    mContext.startActivity(intent);

                } else { // go to UserDetailActivity
                    Intent intent = new Intent(mContext, UserDetailActivity.class);
                    intent.putExtra("DETAIL_USER_ID", _assigned);
                    mContext.startActivity(intent);

                }
            }
        });

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, TaskDetailActivity.class);
                intent.putExtra(UP_NAVIGATION_EXTRA, "TaskOverviewActivity");
                intent.putExtra(TASK_ID_EXTRA, _taskid);
                mContext.startActivity(intent);
            }
        });

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CheckBox done = (CheckBox)view.findViewById(R.id.doneCheckbox);
                DBTools db = new DBTools(mContext);
                db.setTaskCompletion(_taskid, (done.isChecked())?"1":"0");
                TaskOverviewActivity tskOverView = (TaskOverviewActivity)mContext;
                tskOverView.requestOnResume();
            }
        });

        return rowView;
    }

    private String shorten(String text, int numChar) {
        if (text.length() > numChar) {
            return String.format("%s...", text.substring(0, numChar-3));
        }
        return text;
    }
}
