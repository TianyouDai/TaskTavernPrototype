package tasktavern.com.tasktavern;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random;

/**
 * Created by richardhayes on 2017-10-24.
 */

public class SampleDataCreator {

    private Context mContext;

    public SampleDataCreator(Context context) {
        mContext = context;
    }

    public void createData() {
        DBTools db = new DBTools(mContext);
        db.resetDB();

        //
        // create users
        //
        int defaultPasscode = 1111;
        db.createUser("Joshua",   defaultPasscode); // 1
        db.createUser("Margaret", defaultPasscode); // 2
        db.createUser("Finn",     defaultPasscode); // 3
        db.createUser("Jake",     defaultPasscode); // 4
        db.createUser("BMO",      defaultPasscode);  // 5

        //String date1 = "2017-10-24";
        //String date2 = "2017-10-26";

        SimpleDateFormat dbFormat = new SimpleDateFormat("yyyy-MM-dd");

        GregorianCalendar todayDate = new GregorianCalendar();
        String today = dbFormat.format(todayDate.getTime());

        GregorianCalendar date = new GregorianCalendar();

        // task and group ids
        ArrayList<Long> taskIds  = new ArrayList<>();
        ArrayList<Long> groupIds = new ArrayList<>();

        //
        // create groups
        //
        groupIds.add(db.createGroup("Kitchen"));
        groupIds.add(db.createGroup("Living room"));
        groupIds.add(db.createGroup("Garden"));
        groupIds.add(db.createGroup("Bedroom"));

        //
        // create tasks
        //
        date.add(Calendar.DATE, -5);
        taskIds.add(db.createTask(createTaskHashMap(
            "Wash Dishes", // title
                "3",   // assigned
                "0",   // hours
                "45",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "Fill the sink with hot water, and use soap", // description
                "kitchen", // category
                today,     // created
                "2",       // created by
                "0",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 5);
        taskIds.add(db.createTask(createTaskHashMap(
                "Set the dinner table", // title
                "-1",   // assigned
                "0",   // hours
                "15",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "Place the cutlery and glasses on the table", // description
                "Dinning room", // category
                today,     // created
                "1",       // created by
                "1",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 1);
        taskIds.add(db.createTask(createTaskHashMap(
                "Dust Living room", // title
                "4",   // assigned
                "0",   // hours
                "15",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "Dust all the shelves and behind the tv", // description
                "Living room", // category
                today,     // created
                "2",       // created by
                "1",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 2);
        taskIds.add(db.createTask(createTaskHashMap(
                "Download Update", // title
                "5",   // assigned
                "1",   // hours
                "15",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "Plug into the outlet in the corner", // description
                "Operating System", // category
                today,     // created
                "2",       // created by
                "0",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 3);
        taskIds.add(db.createTask(createTaskHashMap(
                "Pick up the mail", // title
                "-1",   // assigned
                "0",   // hours
                "45",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "Bring the notice to the post office and pick up three parcels", // description
                "In town", // category
                today,     // created
                "1",       // created by
                "1",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 1);
        taskIds.add(db.createTask(createTaskHashMap(
                "Rake Lawn", // title
                "1",   // assigned
                "1",   // hours
                "0",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "The rake and bags are in the shed", // description
                "Outside", // category
                today,     // created
                "1",       // created by
                "1",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 1);
        taskIds.add(db.createTask(createTaskHashMap(
                "Take out Trash", // title
                "3",   // assigned
                "0",   // hours
                "5",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "There are two bins in the garage. Put them by the curb", // description
                "Outside", // category
                today,     // created
                "2",       // created by
                "1",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 1);
        taskIds.add(db.createTask(createTaskHashMap(
                "Make bed", // title
                "4",   // assigned
                "0",   // hours
                "5",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "If covers are dirty, put them in the laundry bin", // description
                "Bedroom", // category
                today,     // created
                "2",       // created by
                "1",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 1);
        taskIds.add(db.createTask(createTaskHashMap(
                "Do Homework", // title
                "3",   // assigned
                "2",   // hours
                "0",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "Let me know if you need help, I'll get home at 5pm each day this week", // description
                "Study", // category
                today,     // created
                "2",       // created by
                "1",       // recurring
                "0"        // complete
        )));
        taskIds.add(db.createTask(createTaskHashMap(
                "Practice Viola", // title
                "4",   // assigned
                "1",   // hours
                "30",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "If it's not raining, you can practice outside in the garden", // description
                "Outside/Bedroom", // category
                today,     // created
                "2",       // created by
                "1",       // recurring
                "0"        // complete
        ))); date.add(Calendar.DATE, 1);
        taskIds.add(db.createTask(createTaskHashMap(
                "Get Groceries", // title
                "2",   // assigned
                "1",   // hours
                "30",  // minutes
                getDBDateString(date), // deadline
                "0",   // optional
                "Remember to bring the coupons", // description
                "In Town", // category
                today,     // created
                "2",       // created by
                "1",       // recurring
                "0"        // complete
        )));

        //
        // add tasks to random groups
        //
        Random rand = new Random();
        for (Long id : taskIds) {
            db.addTaskToGroup(
                    Long.toString(id),
                    Long.toString(groupIds.get(rand.nextInt(4)))
            );
        }

        //
        // create resources for tasks
        //
        String[] names = new String[]{"shovel", "fruit", "hammer", "chemicals", "napsack", "lawn mower", "cable", "milk"};
        for (Long id : taskIds) {
            HashMap<String, String> res = new HashMap<>();
            res.put("taskid", Long.toString(id));
            res.put("name", names[rand.nextInt(names.length)]);
            db.createResource(res);
        }

        //
        // create messages
        //
        db.createMessage(createMessageHashMap(
                "1", "3",
                "Hey Finn remember to take all three garbage containers out",
                "2017-10-24 13:45:00", "0"
        ));
        db.createMessage(createMessageHashMap(
                "3", "1",
                "Sure thing, I'll do it right after school",
                "2017-10-24 13:45:05", "0"
        ));
        db.createMessage(createMessageHashMap(
                "1", "3",
                "Thanks",
                "2017-10-24 13:45:10", "0"
        ));
        db.createMessage(createMessageHashMap(
                "3", "1",
                "Do you have the code for the garage door?",
                "2017-10-24 13:45:15", "0"
        ));
        db.createMessage(createMessageHashMap(
                "1", "3",
                "It's on the counter",
                "2017-10-24 13:45:20", "0"
        ));

        db.createMessage(createMessageHashMap(
                "3", "4",
                "Hey Jake, lets go on an adventure tomorrow",
                "2017-10-24 13:45:25", "0"
        ));
        db.createMessage(createMessageHashMap(
                "4", "3",
                "What kind of adventure?",
                "2017-10-24 13:45:30", "0"
        ));
        db.createMessage(createMessageHashMap(
                "4", "3",
                "Isn't it going to rain tomorrow?",
                "2017-10-24 13:45:35", "0"
        ));
        db.createMessage(createMessageHashMap(
                "3", "4",
                "We need to help slime princess find her crown. It might rain, but I'll just bring that anti-rain jacket we found",
                "2017-10-24 13:45:40", "0"
        ));
        db.createMessage(createMessageHashMap(
                "4", "3",
                "Ok, sounds good buddy",
                "2017-10-24 13:45:45", "0"
        ));

        db.createMessage(createMessageHashMap(
                "2", "4",
                "Jake, do you remember where I left my sword",
                "2017-10-24 13:45:50", "0"
        ));
        db.createMessage(createMessageHashMap(
                "4", "2",
                "I took it too school Mom. I told you it's show and tell today",
                "2017-10-24 13:45:55", "0"
        ));
        db.createMessage(createMessageHashMap(
                "2", "4",
                "Oh right, well, remember to bring it back home with you",
                "2017-10-24 13:46:00", "0"
        ));
        db.createMessage(createMessageHashMap(
                "4", "2",
                "Ok Mom",
                "2017-10-24 13:46:15", "0"
        ));

        db.createMessage(createMessageHashMap(
                "5", "2",
                "This is BMO. My software update is all done",
                "2017-10-24 13:46:20", "0"
        ));
        db.createMessage(createMessageHashMap(
                "2", "5",
                "Thanks BMO",
                "2017-10-24 13:46:25", "0"
        ));


        //
        // create shopping list
        //
        db.createShoppingItem("Bacon", "0");
        db.createShoppingItem("Pancakes", "0");
        db.createShoppingItem("Cheese", "0");
        db.createShoppingItem("Tuna", "0");
        db.createShoppingItem("Milk", "0");
        db.createShoppingItem("Eggs", "0");
        db.createShoppingItem("Bread", "0");
        db.createShoppingItem("Fire Wood", "0");
        db.createShoppingItem("Ice cream", "0");
        db.createShoppingItem("Chips", "0");
        db.createShoppingItem("Steaks", "0");
        db.createShoppingItem("Fish", "0");
        db.createShoppingItem("Hot Chocolait", "0");

    }


    // PRIVATE HELPER METHODS
    private HashMap<String, String> createTaskHashMap(String title, String assigned, String hours,
                              String minutes, String deadline, String optional,
                              String description, String category, String created,
                              String createdby, String recurring, String complete) {

        HashMap<String, String> rtn = new HashMap<>();
        rtn.put("title", title);
        rtn.put("assigned", assigned);
        rtn.put("hours", hours);
        rtn.put("minutes", minutes);
        rtn.put("deadline", deadline);
        rtn.put("optional", optional);
        rtn.put("description", description);
        rtn.put("category", category);
        rtn.put("created", created);
        rtn.put("createdby", createdby);
        rtn.put("recurring", recurring);
        rtn.put("complete", complete);

        return rtn;
    }

    private HashMap<String, String> createMessageHashMap(String sender, String recipient, String content, String sent, String viewed) {

        HashMap<String, String> rtn = new HashMap<>();
        rtn.put("sender", sender);
        rtn.put("recipient", recipient);
        rtn.put("content", content);
        rtn.put("sent", sent);
        rtn.put("viewed", viewed);

        return rtn;
    }

    private String getDBDateString(GregorianCalendar date) {
        SimpleDateFormat dbFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dbFormat.format(date.getTime());
    }
}
