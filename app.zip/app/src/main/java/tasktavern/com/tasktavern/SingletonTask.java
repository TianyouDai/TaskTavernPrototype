package tasktavern.com.tasktavern;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-11-30.
 */

public class SingletonTask {

    private static SingletonTask instance = null;

    // NOTE - class is basically just a container for these properties
    // and is much lighter weight if the elements are made public
    // rather than having several getters and setters
    public String ASSIGNED_USER_ID;
    public int HOUR_VALUE;
    public int MINUTES_VALUE;
    public String DEADLINE_DATE;
    public ArrayList<String> RESOURCE_ITEMS;
    public ArrayList<String> GROUPS; // tracks the groups that belong to this task

    HashMap<String, String> info;

    private SingletonTask() {
        // private constructor for singleton class
    }

    public static SingletonTask getInstance() {
        if (instance == null) {
            instance = new SingletonTask();
        }
        return instance;
    }

    public void clearData() {
        RESOURCE_ITEMS   = new ArrayList<>();
        GROUPS           = new ArrayList<>();
        ASSIGNED_USER_ID = "-1"; // default userid is unassigned
        DEADLINE_DATE    = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
        HOUR_VALUE       = 0;
        MINUTES_VALUE    = 0;
    }

    public void load(HashMap<String, String> taskInfo) {
        info = taskInfo;
    }

    public String get(String value) {
        return info.get(value);
    }

    // called by inflateGroupSelectionArea in order to
    // track the assigned groups
    void modifyGroups(String _groupid, boolean b) {
        if (b) {
            if (!GROUPS.contains(_groupid)) {
                // added _groupid
                GROUPS.add(_groupid);
            }

        } else {
            // removed _groupid
            GROUPS.remove(_groupid);
        }
    }

}
