package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;

public class LoginActivity extends AppCompatActivity {
    private final String UP_NAVIGATION_EXTRA = "UP_NAVIGATION";

    public static String CURRENT_USER_ID;

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mListView = (ListView) findViewById(R.id.userList);

        DBTools db = new DBTools(this);
        final ArrayList<HashMap<String, String>> userList = db.getUsers();

        LoginAdapter adapter = new LoginAdapter(this, userList);
        mListView.setAdapter(adapter);

    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);
        final ArrayList<HashMap<String, String>> userList = db.getUsers();
        LoginAdapter adapter = new LoginAdapter(this, userList);
        mListView.setAdapter(adapter);

    }
    public void requestOnResume() {
        onResume();
    }

    public void createUser(View view) {
        Intent intent = new Intent(this, CreateUserActivity.class);
        startActivity(intent);
    }

    public void helpPage(View view) {
        Intent intent = new Intent(this, HelpActivity.class);
        intent.putExtra(UP_NAVIGATION_EXTRA, "LoginActivity");
        startActivity(intent);
    }

    public void shopPage(View view) {
        Intent intent = new Intent(this, ShoppingListActivity.class);
        startActivity(intent);
    }

    public void settingsPage(View view) {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

}
