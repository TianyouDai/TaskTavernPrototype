package tasktavern.com.tasktavern;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-11-04.
 */

public class AddResourceAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<String> mDataSource;
    private LayoutInflater mInflater;

    public AddResourceAdapter(Context context, ArrayList<String> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public String getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        // Get view for row item
        View rowView = mInflater.inflate(R.layout.resource_list_item, viewGroup, false);

        // get elements
        TextView itemNameTextView = (TextView) rowView.findViewById(R.id.itemNameTextView);
        Button deleteBtn = (Button) rowView.findViewById(R.id.deleteBtn);

        String name = getItem(position);

        itemNameTextView.setText(name);

        final int _position = position;
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDataSource.remove(_position);
                ((AddResourceActivity)mContext).requestOnResume();
            }
        });

        return rowView;
    }

}
