package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PasscodeActivity extends AppCompatActivity {

    private String currentCode = "";
    private String PASSCODE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passcode);

        Bundle extras = getIntent().getExtras();
        PASSCODE = extras.getString("LOGIN_ACTIVITY.PASSCODE");

    }

    void displayCode(String code, TextView codeView){
        String displayCode = "";
        for (Character c : code.toCharArray()) {
            displayCode += " " + c;
        }
        int count = 4 - code.length();
        while (count > 0){
            displayCode += " " + "_";
            count -= 1;
        }
        displayCode += " ";
        codeView.setText(displayCode);
    }

    public void keyPress(View view){

        String key = ((Button)view).getText().toString();
        currentCode += key;

        TextView codeView = (TextView)findViewById(R.id.passcodeTextView);
        displayCode(currentCode, codeView);

        if (currentCode.equals(PASSCODE)) {
            Intent intent = new Intent(this, TaskOverviewActivity.class);
            startActivity(intent);
            finish();

        } else if (currentCode.length() == 4) {
            currentCode = "";
            codeView.setText(" _ _ _ _ ");
        }
    }
}
