package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;

public class MessageActivity extends AppCompatActivity {

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        mListView = (ListView) findViewById(R.id.conversationList);

    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);
        final ArrayList<HashMap<String, String>> conversationList = db.getMostRecentMsgPerUser(LoginActivity.CURRENT_USER_ID);
        MessageAdapter adapter = new MessageAdapter(this, conversationList);
        mListView.setAdapter(adapter);

    }

    public void createMessage(View view) {
        Intent intent = new Intent(this, SendMessageActivity.class);
        startActivity(intent);
    }
}
