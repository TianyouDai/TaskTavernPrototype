package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;

import java.util.ArrayList;
import java.util.HashMap;

public class AssignUserActivity extends AppCompatActivity {
    private final String TASK_ID_EXTRA = "TAVERN_TASK_ID";

    ArrayList<RadioButton> radioButtons;
    private String SELECTED_USER_ID;
    private String TASKID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_user);

        Bundle extras = getIntent().getExtras();
        TASKID = extras.getString(TASK_ID_EXTRA);

        // build list of users that can be assigned as recipient
        radioButtons = new ArrayList<>();
        inflateAssignedUserSelectionArea();
    }

    void inflateAssignedUserSelectionArea() {

        // get users
        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> userList = db.getUsers();

        // insert unassigned user
        HashMap<String, String> unassigned = new HashMap<>();
        unassigned.put("userid", "-1");
        unassigned.put("username", "unassigned");
        userList.add(userList.size(), unassigned);

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // for each user inflate a view
        boolean toggle    = true;
        boolean firstUser = true;
        for (HashMap<String, String> user : userList) {
            // get userid
            final String _userid = user.get("userid");

            // get inflatable view
            View rowView = mInflater.inflate(R.layout.user_assigned_item, null);

            // inflate view
            RadioButton userItem = (RadioButton) rowView.findViewById(R.id.userSelectRadioBtn);
            userItem.setText(user.get("username"));
            userItem.setId(Integer.parseInt(_userid));

            // default check the first user in the list
            if (firstUser) {
                SELECTED_USER_ID = _userid;
                userItem.setChecked(true);
                firstUser = false;
            }

            // track created radio button
            radioButtons.add(userItem);

            // set up click listener
            userItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SELECTED_USER_ID = _userid;
                    clearRadioButtons();
                    ((RadioButton)view).setChecked(true);
                }
            });

            // get inflated views parent
            ViewGroup group;
            if (toggle) {
                group = (ViewGroup)findViewById(R.id.leftUserSelectColumn);

            } else {
                group = (ViewGroup)findViewById(R.id.rightUserSelectColumn);

            }
            toggle = !toggle;

            // insert view at correct location
            group.addView(rowView);

        }

    }

    void clearRadioButtons() {
        for (RadioButton btn : radioButtons) {
            btn.setChecked(false);
        }
    }

    public void assignUser(View view) {
        DBTools db = new DBTools(this);
        db.setTaskAssignedUser(TASKID, SELECTED_USER_ID);

        Intent intent = new Intent(this, TaskOverviewActivity.class);
        startActivity(intent);
        finish();
    }

}
