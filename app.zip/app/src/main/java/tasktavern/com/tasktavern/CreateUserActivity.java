package tasktavern.com.tasktavern;

import android.app.ActionBar;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import java.util.ArrayList;

public class CreateUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);
        ArrayList<NumberPicker> nps = new ArrayList<>();
        nps.add((NumberPicker) findViewById(R.id.numberPicker1));
        nps.add((NumberPicker) findViewById(R.id.numberPicker2));
        nps.add((NumberPicker) findViewById(R.id.numberPicker3));
        nps.add((NumberPicker) findViewById(R.id.numberPicker4));

        setupNumberPickers(nps);
    }

    void setupNumberPickers(ArrayList<NumberPicker> numberPickers){
        String[] nums = new String[9];
        for(int i=0; i<nums.length; i++) {
            nums[i] = Integer.toString(i+1);
        }

        for (NumberPicker p : numberPickers){
            p.setMinValue(1);
            p.setMaxValue(9);
            p.setWrapSelectorWheel(false);
            p.setDisplayedValues(nums);
            p.setValue(1);

        }
    }

    public void createUser(View view) {

        EditText username = (EditText) findViewById(R.id.usernameEditText);
        NumberPicker n1 = (NumberPicker) findViewById(R.id.numberPicker1);
        NumberPicker n2 = (NumberPicker) findViewById(R.id.numberPicker2);
        NumberPicker n3 = (NumberPicker) findViewById(R.id.numberPicker3);
        NumberPicker n4 = (NumberPicker) findViewById(R.id.numberPicker4);

        int code = n1.getValue() * 1000 + n2.getValue() * 100 + n3.getValue() * 10 + n4.getValue();

        String name = username.getText().toString();

        if ( !TextUtils.isEmpty(name) ) {

            if (name.length() < 2) {
                Toast.makeText(this, "Username must be at least 2 characters", Toast.LENGTH_LONG).show();

            } else {
                DBTools db = new DBTools(this);
                db.createUser(
                        username.getText().toString(),
                        code
                );
                finish();
            }

        } else {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_LONG).show();

        }

    }
}

