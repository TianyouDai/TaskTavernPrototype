package tasktavern.com.tasktavern;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class MessageDetailActivity extends AppCompatActivity {
    private final String SENDER_ID_EXTRA = "SENDER_ID";

    private String SENDER_ID;

    private ListView mListView;
    private MessageDetailAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_detail);

        Bundle extras = getIntent().getExtras();
        SENDER_ID = extras.getString(SENDER_ID_EXTRA);

        mListView = (ListView) findViewById(R.id.messageList);

        DBTools db = new DBTools(this);
        String username = db.getUsernameFromID(SENDER_ID);
        ((TextView)findViewById(R.id.activityTitleText)).setText(String.format("Conversation with %s", username));
    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);
        final ArrayList<HashMap<String, String>> messageList = db.getMessageFeed(LoginActivity.CURRENT_USER_ID, SENDER_ID);
        mAdapter = new MessageDetailAdapter(this, messageList);
        mListView.setAdapter(mAdapter);
        scrollMyListViewToBottom();

    }

    public void sendMessage(View view) {
        TextView contentTextView = (TextView) findViewById(R.id.messageContentToSend);

        HashMap<String, String> msg = new HashMap<>();
        msg.put("sender", LoginActivity.CURRENT_USER_ID);
        msg.put("recipient", SENDER_ID);
        msg.put("content", contentTextView.getText().toString());
        msg.put("sent", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        msg.put("viewed", "0");

        DBTools db = new DBTools(this);
        db.createMessage(msg);

        contentTextView.setText("");

        onResume();
    }

    private void scrollMyListViewToBottom() {
        mListView.post(new Runnable() {
            @Override
            public void run() {
                mListView.setSelection(mAdapter.getCount() - 1);
            }
        });
    }
}
