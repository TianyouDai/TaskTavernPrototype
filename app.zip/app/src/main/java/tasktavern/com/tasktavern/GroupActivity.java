package tasktavern.com.tasktavern;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class GroupActivity extends AppCompatActivity {

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        mListView = (ListView) findViewById(R.id.groupList);
    }

    @Override
    protected void onResume() {
        super.onResume();

        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> groupList = db.getGroups();

        GroupAdapter adapter = new GroupAdapter(this, groupList);
        mListView.setAdapter(adapter);

    }

    public void requestOnResume() {
        onResume();
    }

    public void addItemBtn(View view) {
        DBTools db = new DBTools(this);
        TextView itemNameTextView = (TextView) findViewById(R.id.newItemEditText);
        String name = itemNameTextView.getText().toString();

        if (!name.equals("")) {
            db.createGroup(name);
            itemNameTextView.setText("");
            onResume(); // refresh group list
        }
    }

}
