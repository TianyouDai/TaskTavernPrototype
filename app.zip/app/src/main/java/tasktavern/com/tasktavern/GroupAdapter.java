package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-11-04.
 */

public class GroupAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<HashMap<String, String>> mDataSource;
    private LayoutInflater mInflater;

    public GroupAdapter(Context context, ArrayList<HashMap<String, String>> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        // Get view for row item
        View rowView = mInflater.inflate(R.layout.group_list_item, viewGroup, false);

        // get elements
        TextView groupItemTextView = (TextView)rowView.findViewById(R.id.groupItemTextView);
        Button viewTasksBtn        = (Button)rowView.findViewById(R.id.viewTasksBtn);
        Button viewResourcesBtn    = (Button)rowView.findViewById(R.id.viewResourcesBtn);
        Button deleteBtn           = (Button)rowView.findViewById(R.id.deleteBtn);

        HashMap<String, String> group = (HashMap<String, String>)getItem(position);

        groupItemTextView.setText(group.get("name"));

        final String _groupid = group.get("groupid");

        viewTasksBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, GroupTasksActivity.class);
                intent.putExtra("GROUPID", _groupid);
                mContext.startActivity(intent);
            }
        });

        viewResourcesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, GroupResourcesActivity.class);
                intent.putExtra("GROUPID", _groupid);
                mContext.startActivity(intent);
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBTools db = new DBTools(mContext);
                db.deleteGroup(_groupid);
                ((GroupActivity)mContext).requestOnResume();
            }
        });


        return rowView;
    }

}
