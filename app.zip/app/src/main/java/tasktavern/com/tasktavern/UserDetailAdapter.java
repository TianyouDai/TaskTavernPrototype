package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-10-24.
 */

public class UserDetailAdapter extends BaseAdapter {
    private final String TASK_ID_EXTRA = "TAVERN_TASK_ID";

    private Context mContext;
    private ArrayList<HashMap<String, String>> mDataSource;
    private LayoutInflater mInflater;

    public UserDetailAdapter(Context context, ArrayList<HashMap<String, String>> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private String formatDate(String dateString) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = df.parse(dateString);
            return new SimpleDateFormat("dd MMM yy").format(date);

        } catch (Exception e) {
            return dateString;

        }
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {//view template

        // Get view for row item
        View rowView = mInflater.inflate(R.layout.task_list_item, viewGroup, false);//get called automatically

        // get elements
        Button userIcon   = (Button) rowView.findViewById(R.id.userIconBtn);
        TextView taskname = (TextView) rowView.findViewById(R.id.tasknameTextView);
        TextView deadline = (TextView) rowView.findViewById(R.id.deadlineTextView);
        TextView note     = (TextView) rowView.findViewById(R.id.noteTextView);
        CheckBox done     = (CheckBox) rowView.findViewById(R.id.doneCheckbox);

        // inflate rowView
        HashMap<String, String> task = (HashMap<String, String>) getItem(position);

        final String _taskid   = task.get("taskid");

        DBTools db = new DBTools(mContext);
        String username = db.getUsernameFromID(task.get("assigned"));
        userIcon.setText(username.substring(0, 2));

        taskname.setText(task.get("title"));//make the program look nicer
        deadline.setText(formatDate(task.get("deadline")));
        note.setText(String.format("note: %s", shorten(task.get("description"), 11)));

        done.setChecked( (task.get("complete").equals("1")?true:false) );

        // assign click handelers
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//done = check something/checkbox, when its clicked, get a reference.
                CheckBox done = (CheckBox)view.findViewById(R.id.doneCheckbox);
                DBTools db = new DBTools(mContext);
                db.setTaskCompletion(_taskid, (done.isChecked())?"1":"0");

            }
        });

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, TaskDetailActivity.class);
                intent.putExtra(TASK_ID_EXTRA, _taskid);
                mContext.startActivity(intent);
            }
        });

        return rowView;
    }

    private String shorten(String text, int numChar) {
        if (text.length() > numChar) {
            return String.format("%s...", text.substring(0, numChar-3));
        }
        return text;
    }
}
