package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class TaskEditActivity extends AppCompatActivity {
    private final String TASK_ID_EXTRA = "TAVERN_TASK_ID";

    private String TASK_ID;

    private SingletonTask st;

    ArrayList<RadioButton> radioButtons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_edit);

        st = SingletonTask.getInstance();
        st.clearData();

        Bundle extras = getIntent().getExtras();
        TASK_ID = extras.getString(TASK_ID_EXTRA);

        DBTools db = new DBTools(this);
        st.load( db.getTaskWithID(TASK_ID) );

        st.RESOURCE_ITEMS   = toStringArrayList(db.getResourcesForTask(TASK_ID));
        st.ASSIGNED_USER_ID = st.get("assigned");

        // set task title
        ((TextView)findViewById(R.id.taskTitleEditText)).setText(st.get("title"));

        // build list of users that can be assigned the task
        radioButtons = new ArrayList<>();
        inflateAssignedUserSelectionArea();

        // inform singleton which groups this task belongs too
        HashMap<String, Boolean> taskGroups = (HashMap<String, Boolean>) db.getGroupIdsForTask(TASK_ID);
        for (String groupid : taskGroups.keySet()) { st.modifyGroups(groupid, true); }

        // allow user to select groups to assign to this task
        inflateGroupSelectionArea();

        // default deadline is today
        st.DEADLINE_DATE = st.get("deadline");
        TextView deadline = (TextView)findViewById(R.id.deadlineTextView);
        deadline.setText(String.format("deadline: %s", formatDate(st.DEADLINE_DATE)));

        // set duration
        setMinutes(st.get("minutes"));
        setHour(st.get("hours"));

        // description and catagory
        ((TextView)findViewById(R.id.descriptionEditText)).setText(st.get("description"));

        TextView nResourcesTextView = (TextView) findViewById(R.id.nResourcesTextView);
        nResourcesTextView.setText("Number of Resources: " + Integer.toString(st.RESOURCE_ITEMS.size()));

    }

    private ArrayList<String> toStringArrayList(ArrayList<HashMap<String, String>> resources) {
        ArrayList<String> rtn = new ArrayList<>();
        for (HashMap<String, String> item : resources) {
            rtn.add(item.get("name"));
        }
        return rtn;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                Intent intent = new Intent(this, TaskDetailActivity.class);
                intent.putExtra(TASK_ID_EXTRA, TASK_ID);
                startActivity(intent);
                finish();

                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();


    }

    private String formatDate(String dateString) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = df.parse(dateString);
            return new SimpleDateFormat("dd MMM yy").format(date);

        } catch (Exception e) {
            return dateString;

        }
    }

    void clearAllHours() {

        Button b0 = (Button) findViewById(R.id.hrsBtn0);
        Button b1 = (Button) findViewById(R.id.hrsBtn1);
        Button b2 = (Button) findViewById(R.id.hrsBtn2);
        Button b3 = (Button) findViewById(R.id.hrsBtn3);
        Button b4 = (Button) findViewById(R.id.hrsBtn4);
        Button b5 = (Button) findViewById(R.id.hrsBtn5);

        b0.setBackgroundResource(R.drawable.buttonshape);
        b1.setBackgroundResource(R.drawable.buttonshape);
        b2.setBackgroundResource(R.drawable.buttonshape);
        b3.setBackgroundResource(R.drawable.buttonshape);
        b4.setBackgroundResource(R.drawable.buttonshape);
        b5.setBackgroundResource(R.drawable.buttonshape);

    }

    void clearAllMinutes() {

        Button b0 = (Button) findViewById(R.id.minBtn0);
        Button b1 = (Button) findViewById(R.id.minBtn5);
        Button b2 = (Button) findViewById(R.id.minBtn10);
        Button b3 = (Button) findViewById(R.id.minBtn15);
        Button b4 = (Button) findViewById(R.id.minBtn30);
        Button b5 = (Button) findViewById(R.id.minBtn45);

        b0.setBackgroundResource(R.drawable.buttonshape);
        b1.setBackgroundResource(R.drawable.buttonshape);
        b2.setBackgroundResource(R.drawable.buttonshape);
        b3.setBackgroundResource(R.drawable.buttonshape);
        b4.setBackgroundResource(R.drawable.buttonshape);
        b5.setBackgroundResource(R.drawable.buttonshape);

    }


    public void hourSelect(View view) {
        clearAllHours();
        view.setBackgroundResource(R.drawable.buttonshape_selected);

        switch (view.getId()) {

            case R.id.hrsBtn0:
                st.HOUR_VALUE = 0;
                break;
            case R.id.hrsBtn1:
                st.HOUR_VALUE = 1;
                break;
            case R.id.hrsBtn2:
                st.HOUR_VALUE = 2;
                break;
            case R.id.hrsBtn3:
                st.HOUR_VALUE = 3;
                break;
            case R.id.hrsBtn4:
                st.HOUR_VALUE = 4;
                break;
            case R.id.hrsBtn5:
                st.HOUR_VALUE = 5;
                break;

        }
    }

    public void setHour(String hour) {
        switch (hour) {

            case "0":
                ((Button)findViewById(R.id.hrsBtn0)).callOnClick();
                break;
            case "1":
                ((Button)findViewById(R.id.hrsBtn1)).callOnClick();
                break;
            case "2":
                ((Button)findViewById(R.id.hrsBtn2)).callOnClick();
                break;
            case "3":
                ((Button)findViewById(R.id.hrsBtn3)).callOnClick();
                break;
            case "4":
                ((Button)findViewById(R.id.hrsBtn4)).callOnClick();
                break;
            case "5":
                ((Button)findViewById(R.id.hrsBtn5)).callOnClick();
                break;

        }
    }

    public void minuteSelect(View view) {
        clearAllMinutes();
        view.setBackgroundResource(R.drawable.buttonshape_selected);

        switch (view.getId()) {

            case R.id.minBtn0:
                st.MINUTES_VALUE = 0;
                break;
            case R.id.minBtn5:
                st.MINUTES_VALUE = 5;
                break;
            case R.id.minBtn10:
                st.MINUTES_VALUE = 10;
                break;
            case R.id.minBtn15:
                st.MINUTES_VALUE = 15;
                break;
            case R.id.minBtn30:
                st.MINUTES_VALUE = 30;
                break;
            case R.id.minBtn45:
                st.MINUTES_VALUE = 45;
                break;

        }
    }

    public void setMinutes(String minutes) {
        clearAllHours();

        switch (minutes) {

            case "0":
                ((Button)findViewById(R.id.minBtn0)).callOnClick();
                break;
            case "5":
                ((Button)findViewById(R.id.minBtn5)).callOnClick();
                break;
            case "10":
                ((Button)findViewById(R.id.minBtn10)).callOnClick();
                break;
            case "15":
                ((Button)findViewById(R.id.minBtn15)).callOnClick();
                break;
            case "30":
                ((Button)findViewById(R.id.minBtn30)).callOnClick();
                break;
            case "45":
                ((Button)findViewById(R.id.minBtn45)).callOnClick();
                break;

        }
    }

    void inflateAssignedUserSelectionArea() {

        // get users
        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> userList = db.getUsers();

        // insert unassigned user
        HashMap<String, String> unassigned = new HashMap<>();
        unassigned.put("userid", "-1");
        unassigned.put("username", "unassigned");
        userList.add(userList.size(), unassigned);

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // for each user inflate a view
        boolean toggle = true;
        for (HashMap<String, String> user : userList) {
            // get userid
            final String _userid = user.get("userid");

            // get inflatable view
            View rowView = mInflater.inflate(R.layout.user_assigned_item, null);

            // inflate view
            RadioButton userItem = (RadioButton) rowView.findViewById(R.id.userSelectRadioBtn);
            userItem.setText(user.get("username"));
            userItem.setId(Integer.parseInt(_userid));

            // default check the unassigned user
            if (user.get("userid").equals(st.ASSIGNED_USER_ID)) {
                userItem.setChecked(true);
            }

            // track created radio button
            radioButtons.add(userItem);

            // set up click listener
            userItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    st.ASSIGNED_USER_ID = _userid;
                    clearRadioButtons();
                    ((RadioButton)view).setChecked(true);
                }
            });

            // get inflated views parent
            ViewGroup group;
            if (toggle) {
                group = (ViewGroup)findViewById(R.id.leftUserSelectColumn);

            } else {
                group = (ViewGroup)findViewById(R.id.rightUserSelectColumn);

            }
            toggle = !toggle;

            // insert view at correct location
            group.addView(rowView);

        }

    }

    void inflateGroupSelectionArea() {

        // clear previous groups to prevent duplicates
        // when user adds a new group
        ((LinearLayout) findViewById(R.id.leftGroupSelectColumn)).removeAllViews();
        ((LinearLayout) findViewById(R.id.rightGroupSelectColumn)).removeAllViews();

        // get groups
        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> groupList = db.getGroups();

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // for each group inflate a view
        boolean toggle = true;
        for (HashMap<String, String> group: groupList) {

            // get groupid
            final String _groupid = group.get("groupid");

            // get inflatable view
            View rowView = mInflater.inflate(R.layout.group_assigned_item, null);

            // inflate view
            CheckBox groupUsedCheckBox = (CheckBox) rowView.findViewById(R.id.groupUsedCheckBox);

            final String _taskid   = TASK_ID;
            final Context mContext = this;

            groupUsedCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                SingletonTask _st = SingletonTask.getInstance();
                _st.modifyGroups(_groupid, b);

                }
            });

            // when group list is inflated make sure to preserve temporary
            // state by querying the singleton
            if (st.GROUPS.contains(_groupid)) {
                groupUsedCheckBox.setChecked(true);
            }

            TextView groupNameTextView = (TextView) rowView.findViewById(R.id.groupNameTextView);
            groupNameTextView.setText(group.get("name"));

            // get inflated views parent
            ViewGroup viewGroup;
            if (toggle) {
                viewGroup = (ViewGroup)findViewById(R.id.leftGroupSelectColumn);

            } else {
                viewGroup = (ViewGroup)findViewById(R.id.rightGroupSelectColumn);

            }
            toggle = !toggle;

            // insert view at correct location
            viewGroup.addView(rowView);

        }

    }

    void clearRadioButtons() {
        for (RadioButton btn : radioButtons) {
            btn.setChecked(false);
        }
    }

    public void pickDeadline(View view) {
        Intent intent = new Intent(this, PickDeadlineActivity.class);
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if(requestCode == 0) {
                st.DEADLINE_DATE = data.getStringExtra("DEADLINE_SELECTED");
                TextView date = (TextView)findViewById(R.id.deadlineTextView);
                date.setText(String.format("deadline: %s", formatDate(st.DEADLINE_DATE)));

            } else if (requestCode == 1) {
                st.RESOURCE_ITEMS = data.getStringArrayListExtra("RESOURCE_ITEMS");
                TextView nResourcesTextView = (TextView) findViewById(R.id.nResourcesTextView);
                nResourcesTextView.setText("Number of Resources: " + Integer.toString(st.RESOURCE_ITEMS.size()));

            }

        }
    }

    public void addResourceBtn(View view) {
        Intent intent = new Intent(this, AddResourceActivity.class);
        intent.putStringArrayListExtra("RESOURCE_ITEMS", st.RESOURCE_ITEMS);
        startActivityForResult(intent, 1);
    }

    public void addNewGroup(View view) {
        EditText addGroupEditText = (EditText) findViewById(R.id.addGroupEditText);
        String groupName = addGroupEditText.getText().toString();
        DBTools dbTools = new DBTools(this);

        if (!groupName.equals("")) {
            dbTools.createGroup(groupName);
            addGroupEditText.setText("");
            inflateGroupSelectionArea(); // clears old groups, and inflates
        }
    }

    public void updateTask(View view) {

        // collect task information
        EditText titleTextView = (EditText)findViewById(R.id.taskTitleEditText);
        String taskTitle = titleTextView.getText().toString();

        EditText descriptionEditText = (EditText)findViewById(R.id.descriptionEditText);
        String description = descriptionEditText.getText().toString();

        // update task in DB
        DBTools db = new DBTools(this);
        HashMap<String, String> task = new HashMap<>();
        task.put("title", taskTitle);
        task.put("assigned", st.ASSIGNED_USER_ID);
        task.put("hours", Integer.toString(st.HOUR_VALUE));
        task.put("minutes", Integer.toString(st.MINUTES_VALUE));
        task.put("deadline", st.DEADLINE_DATE);
        task.put("description", description);
        task.put("created", task.get("created"));
        task.put("createdby", LoginActivity.CURRENT_USER_ID);
        task.put("taskid", TASK_ID);
        db.updateTask(task);

        db.deleteResourcesForTask(TASK_ID);

        for (String name : st.RESOURCE_ITEMS) {
            HashMap<String, String> resource = new HashMap<>();
            resource.put("taskid", TASK_ID);
            resource.put("name", name);
            db.createResource(resource);
        }

        db.deleteGroupsForTask(TASK_ID);

        // add selected task to selected groups
        for (String groupid : st.GROUPS) {
            db.addTaskToGroup(TASK_ID, groupid);

        }

        finish();
    }

}
