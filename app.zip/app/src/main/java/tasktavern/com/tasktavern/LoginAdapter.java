package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-10-09.
 */

public class LoginAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<HashMap<String, String>> mDataSource;
    private LayoutInflater mInflater;

    public LoginAdapter(Context context, ArrayList<HashMap<String, String>> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private String shorten(String str, int length) {
        if (str.length() > length) {
            return str.substring(0, length) + "...";

        } else {
            return str;

        }
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        // Get view for row item
        View rowView = mInflater.inflate(R.layout.user_list_item, viewGroup, false);

        // get elements
        Button userIcon       = (Button) rowView.findViewById(R.id.userIconBtn);
        TextView username     = (TextView) rowView.findViewById(R.id.usernameTextView);
        TextView pendingTasks = (TextView) rowView.findViewById(R.id.numberTasksTextView);
        TextView nextTask     = (TextView) rowView.findViewById(R.id.nextTaskTextView);
        TextView pointValue  = (TextView) rowView.findViewById(R.id.pointValueTextView);

        HashMap<String, String> user = (HashMap<String, String>) getItem(position);

        String name = user.get("username");
        userIcon.setText(String.format("%s", name.substring(0,2).toUpperCase()));
        username.setText(name);

        // get number of tasks and next task
        DBTools db = new DBTools(mContext);
        String numberPendingTasks = Long.toString(db.getPendingTasksForUser(user.get("userid")));
        String nextTaskName = db.getNextTaskForUser(user.get("userid"));

        if (numberPendingTasks.equals("1")) {
            pendingTasks.setText(String.format("%s task", numberPendingTasks));

        } else {
            pendingTasks.setText(String.format("%s tasks", numberPendingTasks));

        }

        nextTask.setText(String.format("Next: %s", shorten(nextTaskName, 16)));

        final String _userid = user.get("userid");
        final String _passcode = user.get("passcode");

        pointValue.setText(Long.toString(db.getCompletedTasksForUser(_userid) * 10));

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, PasscodeActivity.class);
                LoginActivity.CURRENT_USER_ID = _userid;
                intent.putExtra("LOGIN_ACTIVITY.PASSCODE", _passcode);
                mContext.startActivity(intent);
            }
        });

        return rowView;
    }
}
