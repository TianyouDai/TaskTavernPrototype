package tasktavern.com.tasktavern;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by richardhayes on 2017-10-23.
 */

public class ShoppingListAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<HashMap<String, String>> mDataSource;
    private LayoutInflater mInflater;

    public ShoppingListAdapter(Context context, ArrayList<HashMap<String, String>> items){
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        // Get view for row item
        View rowView = mInflater.inflate(R.layout.shopping_list_item, viewGroup, false);

        // get elements
        TextView itemNameTextView = (TextView) rowView.findViewById(R.id.itemNameTextView);
        CheckBox completeCheckbox = (CheckBox) rowView.findViewById(R.id.doneCheckbox);

        HashMap<String, String> item = (HashMap<String, String>) getItem(position);

        itemNameTextView.setText(item.get("name"));

        completeCheckbox.setChecked( item.get("complete").equals("1")?true:false );

        final String _itemid = item.get("itemid");
        completeCheckbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CheckBox completeCheckbox = (CheckBox)view.findViewById(R.id.doneCheckbox);
                DBTools db = new DBTools(mContext);
                db.setItemCompletion(_itemid, (completeCheckbox.isChecked())?"1":"0");

            }
        });

        return rowView;
    }
}
