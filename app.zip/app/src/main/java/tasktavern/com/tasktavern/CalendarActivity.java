package tasktavern.com.tasktavern;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.TreeMap;

public class CalendarActivity extends AppCompatActivity {

    private GregorianCalendar currentDate;
    private TreeMap< String, ArrayList<HashMap<String, String>> > map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);



    }

    @Override
    protected void onResume() {
        super.onResume();

        // get list of all tasks
        DBTools db = new DBTools(this);
        ArrayList<HashMap<String, String>> tasks = db.getTasks();

        // insert tasks into SortedMap of (yyyy-mm-dd -> ArrayList)
        map = new TreeMap<String, ArrayList<HashMap<String, String>>>();
        for (HashMap<String, String> task : tasks) {

            String key = task.get("deadline");

            if (!map.containsKey(key)) {
                ArrayList<HashMap<String, String>> temp = new ArrayList<>();
                map.put(key, temp);
            }

            ArrayList<HashMap<String, String>> taskList = map.get(key);
            taskList.add(task);
            map.put(key, taskList);

        }

        // set current date to previousMonday
        currentDate = previousMonday(new GregorianCalendar());
        updateCalendarView();

    }

    private GregorianCalendar previousMonday(GregorianCalendar cal) {
        while (true) {
            if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
                break;
            }
            cal.add(Calendar.DATE, -1);
        }
        return cal;
    }

    private GregorianCalendar dateCopy(GregorianCalendar date) {
        return new GregorianCalendar(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DAY_OF_MONTH));
    }

    private void clearCalendarView() {
        ((ViewGroup)findViewById(R.id.mondayLayout)).removeAllViews();
        ((ViewGroup)findViewById(R.id.tuesdayLayout)).removeAllViews();
        ((ViewGroup)findViewById(R.id.wednesdayLayout)).removeAllViews();
        ((ViewGroup)findViewById(R.id.thursdayLayout)).removeAllViews();
        ((ViewGroup)findViewById(R.id.fridayLayout)).removeAllViews();
        ((ViewGroup)findViewById(R.id.saturdayLayout)).removeAllViews();
        ((ViewGroup)findViewById(R.id.sundayLayout)).removeAllViews();
    }

    private void updateCalendarView() {
        clearCalendarView();

        GregorianCalendar date = dateCopy(currentDate);
        SimpleDateFormat titleFormat = new SimpleDateFormat("EEEE dd MMM yyyy");
        SimpleDateFormat keyFormat = new SimpleDateFormat("yyyy-MM-dd");

        TextView mondayTextView    = (TextView) findViewById(R.id.mondayTextView);
        TextView tuesdayTextView   = (TextView) findViewById(R.id.tuesdayTextView);
        TextView wednesdayTextView = (TextView) findViewById(R.id.wednesdayTextView);
        TextView thursdayTextView  = (TextView) findViewById(R.id.thursdayTextView);
        TextView fridayTextView    = (TextView) findViewById(R.id.fridayTextView);
        TextView saturdayTextView  = (TextView) findViewById(R.id.saturdayTextView);
        TextView sundayTextView    = (TextView) findViewById(R.id.sundayTextView);

        // set MONDAY TextView and tasks
        String dateString = titleFormat.format(date.getTime());
        mondayTextView.setText(dateString);
        String key = keyFormat.format(date.getTime());
        inflateTaskList(Calendar.MONDAY, map.get(key));

        date.add(Calendar.DATE, 1);

        // set TUESDAY TextView and tasks
        dateString = titleFormat.format(date.getTime());
        tuesdayTextView.setText(dateString);
        key = keyFormat.format(date.getTime());
        inflateTaskList(Calendar.TUESDAY, map.get(key));

        date.add(Calendar.DATE, 1);

        // set WEDNESDAY TextView and tasks
        dateString = titleFormat.format(date.getTime());
        wednesdayTextView.setText(dateString);
        key = keyFormat.format(date.getTime());
        inflateTaskList(Calendar.WEDNESDAY, map.get(key));

        date.add(Calendar.DATE, 1);

        // set THURSDAY TextView and tasks
        dateString = titleFormat.format(date.getTime());
        thursdayTextView.setText(dateString);
        key = keyFormat.format(date.getTime());
        Log.d("CalAct", "Asks for key: " + key);
        inflateTaskList(Calendar.THURSDAY, map.get(key));

        date.add(Calendar.DATE, 1);

        // set FRIDAY TextView and tasks
        dateString = titleFormat.format(date.getTime());
        fridayTextView.setText(dateString);
        key = keyFormat.format(date.getTime());
        inflateTaskList(Calendar.FRIDAY, map.get(key));

        date.add(Calendar.DATE, 1);

        // set SATURDAY TextView and tasks
        dateString = titleFormat.format(date.getTime());
        saturdayTextView.setText(dateString);
        key = keyFormat.format(date.getTime());
        inflateTaskList(Calendar.SATURDAY, map.get(key));

        date.add(Calendar.DATE, 1);

        // set SUNDAY TextView and tasks
        dateString = titleFormat.format(date.getTime());
        sundayTextView.setText(dateString);
        key = keyFormat.format(date.getTime());
        inflateTaskList(Calendar.SUNDAY, map.get(key));

    }

    public void prevBtn(View view) {
        currentDate.add(Calendar.DATE, -7);
        updateCalendarView();
    }

    public void nextBtn(View view) {
        currentDate.add(Calendar.DATE, 7);
        updateCalendarView();
    }

    void inflateTaskList(int day, ArrayList<HashMap<String, String>> tasks) {
        ViewGroup viewGroup;
        switch(day) {
            case Calendar.MONDAY:
                viewGroup = (ViewGroup)findViewById(R.id.mondayLayout);
                break;

            case Calendar.TUESDAY:
                viewGroup = (ViewGroup)findViewById(R.id.tuesdayLayout);
                break;

            case Calendar.WEDNESDAY:
                viewGroup = (ViewGroup)findViewById(R.id.wednesdayLayout);
                break;

            case Calendar.THURSDAY:
                viewGroup = (ViewGroup)findViewById(R.id.thursdayLayout);
                break;

            case Calendar.FRIDAY:
                viewGroup = (ViewGroup)findViewById(R.id.fridayLayout);
                break;

            case Calendar.SATURDAY:
                viewGroup = (ViewGroup)findViewById(R.id.saturdayLayout);
                break;

            case Calendar.SUNDAY:
                viewGroup = (ViewGroup)findViewById(R.id.sundayLayout);
                break;
            default:
                viewGroup = null;
                break;
        }

        // get inflater
        LayoutInflater mInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (tasks != null) {

            for (HashMap<String, String> task : tasks) {
                // get inflatable view
                View rowView = mInflater.inflate(R.layout.group_task_list_item, null);

                TextView taskName = (TextView) rowView.findViewById(R.id.taskNameTextView);
                Button viewBtn = (Button) rowView.findViewById(R.id.viewTaskButton);

                taskName.setText(task.get("title"));

                final Context mContext = this;
                final String _taskid = task.get("taskid");

                viewBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(mContext, TaskDetailActivity.class);
                        intent.putExtra("TAVERN_TASK_ID", _taskid);
                        mContext.startActivity(intent);
                    }
                });

                if (viewGroup != null) { viewGroup.addView(rowView); }

            }

        } else {
            // there are no tasks for this day

            // get inflatable view
            View rowView = mInflater.inflate(R.layout.group_task_list_item, null);

            TextView taskName = (TextView) rowView.findViewById(R.id.taskNameTextView);
            taskName.setText("No Tasks");
            taskName.setTextColor(Color.LTGRAY);


            Button viewBtn = (Button) rowView.findViewById(R.id.viewTaskButton);
            viewBtn.setVisibility(View.GONE);

            viewGroup.addView(rowView);

        }
    }

}
